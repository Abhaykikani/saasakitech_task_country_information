package com.example.saasaki_tech_countryinformation

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
