import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:url_launcher/url_launcher.dart';


class CountryDetailPage extends StatelessWidget {
  final dynamic country;

  CountryDetailPage({required this.country});

  @override
  Widget build(BuildContext context) {
    Map<String, dynamic> translations = country['translations'];
    Map<String, dynamic> flags = country['flags'] ?? {};
    // Map<String, dynamic> coatOfArms = country['coatOfArms'] ?? {};
    String startOfWeek = country['startOfWeek'] ?? '';
    Map<String, dynamic> languages = country['languages'] ?? {};
    Map<String, dynamic> currencies = country['currencies'] ?? {};
    List<dynamic> borders = country['borders'] ?? [];
    double area = country['area'] ?? 0.0;
    List<dynamic> timezones = country['timezones'] ?? [];
    List<dynamic> continents = country['continents'] ?? [];
    Map<String, dynamic> name = country['name'] ?? {};
    Map<String, dynamic> nativeName = name['nativeName'] ?? {};
    Map<String, dynamic> eng = nativeName['eng'] ?? {};

    return Scaffold(
      appBar: AppBar(
        title: Text(country['name']['common'] ?? 'Country Detail'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 20),
            const Text(
              'Additional Information',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            if (country['maps'] != null &&
                country['maps']['googleMaps'] != null)
              GestureDetector(
                onTap: () {
                  _launchURL(country['maps']['googleMaps']);
                },
                child: const Padding(
                  padding: EdgeInsets.symmetric(vertical: 8.0),
                  child: Text(
                    'Google Maps Link',
                    style: TextStyle(
                      color: Colors.blue,
                      decoration: TextDecoration.underline,
                    ),
                  ),
                ),
              ),
            if (country['maps'] != null &&
                country['maps']['openStreetMaps'] != null)
              GestureDetector(
                onTap: () {
                  _launchURLS(country['maps']['openStreetMaps']);
                },
                child: const Padding(
                  padding: EdgeInsets.symmetric(vertical: 8.0),
                  child: Text(
                    'OpenStreetMap Link',
                    style: TextStyle(
                      color: Colors.blue,
                      decoration: TextDecoration.underline,
                    ),
                  ),
                ),
              ),

            const Padding(
              padding: EdgeInsets.only(top: 10, bottom: 10),
              child:
                  Text('Flag:', style: TextStyle(fontWeight: FontWeight.bold)),
            ),

            if (flags['svg'] != null)
              FutureBuilder(
                future: precacheSvg(NetworkImage(flags['svg']).url),
                builder: (BuildContext context, AsyncSnapshot<void> snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return const CircularProgressIndicator();
                  } else if (snapshot.hasError) {
                    return const Text('Error loading SVG');
                  } else {
                    return SizedBox(
                      width: 220,
                      height: 150,
                      child: SvgPicture.network(
                        flags['svg'],
                        fit: BoxFit.cover,
                        placeholderBuilder: (BuildContext context) =>
                            const CircularProgressIndicator(),
                      ),
                    );
                  }
                },
              ),
            Padding(
              padding: const EdgeInsets.only(top: 10, bottom: 15),
              child: Text(flags['alt'] ?? ''),
            ),
            // const Text('Coat of Arms:',
            //     style: TextStyle(fontWeight: FontWeight.bold)),
            // if (coatOfArms['png'] != null)
            //   FutureBuilder(
            //     future: precacheSvg(NetworkImage(coatOfArms['png']).url),
            //     builder: (BuildContext context, AsyncSnapshot<void> snapshot) {
            //       if (snapshot.connectionState == ConnectionState.waiting) {
            //         return CircularProgressIndicator();
            //       } else if (snapshot.hasError) {
            //         return Text('Error loading SVG');
            //       } else {
            //         return SizedBox(
            //           width: 200,
            //           height: 100,
            //           child: SvgPicture.network(
            //             coatOfArms['png'],
            //             fit: BoxFit.cover,
            //             placeholderBuilder: (BuildContext context) =>
            //                 const CircularProgressIndicator(),
            //           ),
            //         );
            //       }
            //     },
            //   ),
            // if (coatOfArms['svg'] != null)
            //   FutureBuilder(
            //     future: precacheSvg(NetworkImage(coatOfArms['svg']).url),
            //     builder: (BuildContext context, AsyncSnapshot<void> snapshot) {
            //       if (snapshot.connectionState == ConnectionState.waiting) {
            //         return CircularProgressIndicator();
            //       } else if (snapshot.hasError) {
            //         return Text('Error loading SVG');
            //       } else {
            //         return SizedBox(
            //           width: 200,
            //           height: 100,
            //           child: SvgPicture.network(
            //             coatOfArms['svg'],
            //             fit: BoxFit.cover,
            //             placeholderBuilder: (BuildContext context) =>
            //                 const CircularProgressIndicator(),
            //           ),
            //         );
            //       }
            //     },
            //   ),

            Text('Official Name: ${name['official'] ?? 'Unknown'}',
                style:
                    const TextStyle(fontWeight: FontWeight.w600, fontSize: 15)),
            const SizedBox(height: 15),

            Text('Common Name: ${name['common'] ?? 'Unknown'}',
                style:
                    const TextStyle(fontWeight: FontWeight.w600, fontSize: 15)),
            const SizedBox(height: 15),

            Text('Capital: ${country['capital']?.join(", ") ?? 'Unknown'}',
                style:
                    const TextStyle(fontWeight: FontWeight.w600, fontSize: 15)),
            const SizedBox(height: 15),

            Text('Population: ${country['population'] ?? 'Unknown'}',
                style:
                    const TextStyle(fontWeight: FontWeight.w600, fontSize: 15)),
            const SizedBox(height: 15),

            Text('Region: ${country['region'] ?? 'Unknown'}',
                style:
                    const TextStyle(fontWeight: FontWeight.w600, fontSize: 15)),
            const SizedBox(height: 15),

            Text('Subregion: ${country['subregion'] ?? 'Unknown'}',
                style:
                    const TextStyle(fontWeight: FontWeight.w600, fontSize: 15)),
            const SizedBox(height: 15),

            if (languages.isNotEmpty) ...[
              Text('Languages: ${languages.values.join(", ")}',
                  style: const TextStyle(
                      fontWeight: FontWeight.w600, fontSize: 15))
            ],
            const SizedBox(height: 15),

            Text("StartOfWeek: ${startOfWeek}",
                style:
                    const TextStyle(fontWeight: FontWeight.w600, fontSize: 15)),
            const SizedBox(height: 15),

            Text("Independent: ${country['independent']}",
                style:
                    const TextStyle(fontWeight: FontWeight.w600, fontSize: 15)),
            const SizedBox(height: 15),

            Text("Status: ${country['status']}",
                style:
                    const TextStyle(fontWeight: FontWeight.w600, fontSize: 15)),
            const SizedBox(height: 15),

            Text("UN Member: ${country['unMember']}",
                style:
                    const TextStyle(fontWeight: FontWeight.w600, fontSize: 15)),
            const SizedBox(height: 15),

            if (currencies.isNotEmpty) ...[
              Text(
                  'Currencies: ${currencies.values.map((currency) => "${currency['name']} (${currency['symbol']})").join(", ")}',
                  style: const TextStyle(
                      fontWeight: FontWeight.w600, fontSize: 15)),
            ],
            const SizedBox(height: 15),

            if (borders.isNotEmpty) ...[
              Text('Borders: ${borders.join(", ")}',
                  style: const TextStyle(
                      fontWeight: FontWeight.w600, fontSize: 15)),
            ],
            Text('Area: ${area.toString()} sq km',
                style:
                    const TextStyle(fontWeight: FontWeight.w600, fontSize: 15)),
            const SizedBox(height: 15),

            if (timezones.isNotEmpty) ...[
              Text('Timezones: ${timezones.join(", ")}',
                  style: const TextStyle(
                      fontWeight: FontWeight.w600, fontSize: 15))
            ],
            const SizedBox(height: 15),

            if (continents.isNotEmpty) ...[
              Text('Continents: ${continents.join(", ")}',
                  style: const TextStyle(
                      fontWeight: FontWeight.w600, fontSize: 15))
            ],

            const SizedBox(height: 15),
            Text('Official Name: ${name['official'] ?? 'Unknown'}',
                style:
                    const TextStyle(fontWeight: FontWeight.w600, fontSize: 15)),
            const SizedBox(height: 15),

            Text('Native Name: ${eng['common'] ?? 'Unknown'}',
                style:
                    const TextStyle(fontWeight: FontWeight.w600, fontSize: 15)),
            const SizedBox(height: 15),

            Text('Official Native Name: ${eng['official'] ?? 'Unknown'}',
                style:
                    const TextStyle(fontWeight: FontWeight.w600, fontSize: 15)),
            const SizedBox(height: 15),

            const Text('Language Translations:',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17)),
            const SizedBox(height: 10),

            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: translations.entries.map((entry) {
                return Padding(
                    padding: const EdgeInsets.symmetric(vertical: 4),
                    child:
                        Text('${entry.key}: ${entry.value['common'] ?? ""}'));
              }).toList(),
            ),
          ],
        ),
      ),
    );
  }

  precacheSvg(String url) {}
  void _launchURL(String url) async {
    if (await canLaunch(url)) {
      await launch(url);
    } else {
      throw 'Could not launch $url';
    }
  }

  void _launchURLS(String url) async {
    if (await canLaunch(url)) {
      await launch(url);
    } else {
      throw 'Could not launch $url';
    }
  }
}
