import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:provider/provider.dart';
import 'package:saasaki_tech_countryinformation/CountryDetailPage.dart';
// import 'package:connectivity/connectivity.dart';

// import 'CountryDetailPage.dart';

void main() {
  runApp(
    ChangeNotifierProvider(
      create: (context) => CountryDataProvider(),
      child: MyApp(),
    ),
  );
}

class CountryDataProvider extends ChangeNotifier {
  Map<String, List<dynamic>> _continentCountries = {};
  List<dynamic> _allCountries = [];

  Map<String, List<dynamic>> get continentCountries => _continentCountries;
  List<dynamic> get allCountries => _allCountries;

  Future<void> fetchData() async {
    // try {
    // var connectivityResult = await Connectivity().checkConnectivity();
    // if (connectivityResult == ConnectivityResult.none) {
    //   throw Exception('No internet connection');
    // }

    var response =
        await http.get(Uri.parse('https://restcountries.com/v3.1/all'));
    if (response.statusCode == 200) {
      List countries = json.decode(response.body);
      _allCountries = countries;
      _continentCountries = {};
      countries.forEach((country) {
        String region = country['region'];
        if (!_continentCountries.containsKey(region)) {
          _continentCountries[region] = [];
        }
        _continentCountries[region]!.add(country);
      });
      notifyListeners();
    } else {
      throw Exception('Failed to load data: ${response.statusCode}');
    }
    // } catch (e) {
    //   print('Error: $e');
    //   throw e; // Propagate the error to UI for better handling
    // }
  }

  List<dynamic> searchCountries(String query) {
    return _allCountries.where((country) {
      String name = country['name']['common'].toLowerCase();
      return name.contains(query.toLowerCase());
    }).toList();
  }
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Countries by Continent',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: FutureBuilder(
        future: Provider.of<CountryDataProvider>(context, listen: false)
            .fetchData(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Scaffold(
              appBar: AppBar(
                title: Text('Countries by Continent'),
              ),
              body: const Center(
                child: CircularProgressIndicator(),
              ),
            );
          } else if (snapshot.hasError) {
            return Scaffold(
              appBar: AppBar(
                title: Text('Error'),
              ),
              body: Center(
                child: Text('Error fetching data: ${snapshot.error}'),
              ),
            );
          } else {
            final provider = Provider.of<CountryDataProvider>(context);
            if (provider.continentCountries.isEmpty) {
              return Scaffold(
                appBar: AppBar(
                  title: const Text('Countries by Continent'),
                ),
                body: const Center(
                  child: Text('No data available'),
                ),
              );
            } else {
              return CountryListScreen(provider: provider);
            }
          }
        },
      ),
    );
  }
}

class CountryListScreen extends StatefulWidget {
  final CountryDataProvider provider;

  const CountryListScreen({required this.provider});

  @override
  _CountryListScreenState createState() => _CountryListScreenState();
}

class _CountryListScreenState extends State<CountryListScreen> {
  late TextEditingController _searchController;
  late String _searchQuery;
  List<dynamic> _filteredCountries = [];

  @override
  void initState() {
    super.initState();
    _searchController = TextEditingController();
    _searchQuery = '';
    _filteredCountries = widget.provider.allCountries;
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Countries by Continent'),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextFormField(
              controller: _searchController,
              decoration: InputDecoration(
                border:
                    OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                labelText: 'Search',
                hintText: 'Enter country name',
                prefixIcon: const Icon(Icons.search),
                suffixIcon: _searchController.text.isNotEmpty
                    ? IconButton(
                        icon: const Icon(Icons.clear),
                        onPressed: () {
                          setState(() {
                            _searchController.clear();
                            _searchQuery = '';
                            _filteredCountries = widget.provider.allCountries;
                          });
                        },
                      )
                    : null,
              ),
              onChanged: (value) {
                setState(() {
                  _searchQuery = value;
                  _filteredCountries = widget.provider.searchCountries(value);
                });
              },
            ),
          ),
          Expanded(
            child: Consumer<CountryDataProvider>(
              builder: (context, provider, child) {
                return ListView.builder(
                  itemCount: provider.continentCountries.length,
                  itemBuilder: (context, index) {
                    String continent =
                        provider.continentCountries.keys.elementAt(index);
                    List<dynamic> countries =
                        provider.continentCountries[continent]!;
                    return ExpansionTile(
                      title: Text(continent),
                      children: countries.map((country) {
                        List<dynamic> capitals =
                            country['capital'] ?? ['Unknown'];
                        return ListTile(
                          title: Text(country['name']['common']),
                          subtitle: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('Capital: ${capitals.join(", ")}'),
                              Text('Population: ${country['population']}'),
                              const SizedBox(height: 10)
                            ],
                          ),
                          leading: CircleAvatar(
                            backgroundImage:
                                NetworkImage(country['flags']['png']),
                          ),
                          onTap: () {
                            _navigateToCountryDetail(context, country);
                          },
                        );
                      }).toList(),
                    );
                  },
                );
              },
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: _filteredCountries.length,
              itemBuilder: (context, index) {
                dynamic country = _filteredCountries[index];
                List<dynamic> capitals = country['capital'] ?? ['Unknown'];
                return ListTile(
                  title: Text(country['name']['common']),
                  subtitle: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Capital: ${capitals.join(", ")}'),
                      Text('Population: ${country['population']}'),
                      const SizedBox(height: 10)
                    ],
                  ),
                  leading: CircleAvatar(
                    backgroundImage: NetworkImage(country['flags']['png']),
                  ),
                  onTap: () {
                    _navigateToCountryDetail(context, country);
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  void _navigateToCountryDetail(BuildContext context, dynamic country) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => CountryDetailPage(country: country),
      ),
    );
  }
}
